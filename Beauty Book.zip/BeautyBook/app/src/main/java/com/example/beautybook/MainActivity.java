package com.example.profileseven;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.beautybook.R;
import com.example.profileseven.Adapter.RecyclerAdapter;
import com.example.profileseven.model.Profileseven_model;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final android.R.attr R = ;
    private RecyclerView recyclerview;

    int image [] = {com.example.beautybook.R.drawable.ps_imgtwo,R.drawable.ps_imgthree,R.drawable.ps_imgone};

    RecyclerAdapter adapter;

    ArrayList<Profileseven_model> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerview = findViewById(R.id.recyclerview);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false);
        recyclerview.setLayoutManager(layoutManager);
        recyclerview.setItemAnimator(new DefaultItemAnimator());

        list = new ArrayList<>();
        adapter = new RecyclerAdapter(MainActivity.this,list);

        for (int i= 0 ; i<image.length ; i++)
        {
            Profileseven_model model = new Profileseven_model(image[i]);
            list.add(model);

        }

        recyclerview.setAdapter(adapter);



    }
}
