package com.example.profileseven.model;

public class Profileseven_model {

    int Image;

    public Profileseven_model(int image) {
        Image = image;
    }

    public int getImage() {
        return Image;
    }

    public void setImage(int image) {
        Image = image;
    }
}

